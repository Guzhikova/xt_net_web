﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task3
{
    class Person
    {
        public Person(int numberOfPerson)
        {
            NumberOfPerson = numberOfPerson;
        }

        public int NumberOfPerson { get; }

    }

}
