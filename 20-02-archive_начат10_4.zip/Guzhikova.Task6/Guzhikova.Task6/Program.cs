﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace Guzhikova.Task6
{
    class Program
    {
        

        static void Main(string[] args)
        {

            var consoleManage = new ConsoleManage();

            consoleManage.СhooseAction();

            Console.ReadKey();
        }        



    }
}
